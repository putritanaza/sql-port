-- Akses kolom "price" dari table "purchases"
SELECT price
FROM purchases;